<!-- Global Overlay Start -->
<div class="zakas-global-overlay"></div>
<!-- Global Overlay End -->