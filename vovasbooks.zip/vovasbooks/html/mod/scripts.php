<!-- ************************* JS Files ************************* -->

<!-- jQuery JS -->
<script src="<?=PATH?>assets/js/vendor.js"></script>

<!-- Main JS -->
<script src="<?=PATH?>assets/js/main.js"></script>

</body>

</html>