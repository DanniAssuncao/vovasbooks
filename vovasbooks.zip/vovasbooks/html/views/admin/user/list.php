
<?php include (HTMLPATH . "modAdmin/head.php"); ?>

<?php include (HTMLPATH . "modAdmin/header.php"); ?>


        <!-- Breadcrumb area Start -->
        <div class="breadcrumb-area bg-color ptb--90" data-bg-color="#f6f6f6">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
                            <h1 class="page-title">List of Users</h1>
                            <ul class="breadcrumb">
                                <li><a href="index.html">Users</a></li>
                                <li class="current"><span>List of users</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Breadcrumb area End -->

        <!-- Main Content Wrapper Start -->
        <div class="main-content-wrapper">
            <div class="page-content-inner">
                <div class="container">
                    <div class="row pt--50 pt-md--40 pt-sm--20">
                        <div class="col-12">
                            <!-- User Action Start -->
                            <div class="user-actions user-actions__coupon">
                                <div class="message-box mb--30">
                                    <p><i class="fa fa-exclamation-circle"></i> <a href="<?=PATH?>admin/user/add" > Add users </a></p>
                                </div>

                            </div>
                            <!-- User Action End -->
                        </div>
                    </div> 
                    <div class="row pb--80 pb-md--60 pb-sm--40">
                        <!-- Checkout Area Start -->


                        <div class="col-lg-12">
                            <table id="example" class="ui celled table" style="width:100%">
                                <thead>

                                    <th>Username</th>
                                    <th>E-mail</th>
                                    <th>Role</th>
                                    <th>Date Created</th>
                                    <th>Last Login</th>

                                    <th>Actions</th>

                                </thead>

                            </table>
                        </div>


                        <!-- Checkout Area End -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Content Wrapper Start -->

<?php include (HTMLPATH . "modAdmin/footer.php"); ?>


<?php include (HTMLPATH . "modAdmin/loader.php"); ?>


<?php include (HTMLPATH . "modAdmin/scripts.php"); ?>


<script>
    $(document).ready(function() {


        var bars = function () {
            var table = $('#example');

            var settings = {
                "sDom": "<t><'row'<p i>>",
                "destroy": true,
                "cache":true,
                "scrollCollapse": true,
                "oLanguage": {
                    "sLengthMenu": "_MENU_ ",
                    "sInfo": "Showing <b>_START_ of _END_</b> of _TOTAL_ record"
                },
                "iDisplayLength": 15,
                "data": <?=$listOfUsers?>,
                columns: [

                    {data: 'username'},
                    {data: 'email'},
                    {data: 'user_role_id.name'},
                    {data: 'date_created'},
                    {data: 'lastLogin'},
                    {
                        data: 'id_user',
                        "orderable": false,
                        "searchable": true,
                        "render": function (data) {
                            return '<div class="dropdown dropdown-default">\n' +
                                ' <button class="btn  dropdown-toggle" type="button"\n' +
                                ' data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">\n' +
                                ' Action\n' +
                                ' </button>\n' +
                                ' <div class="dropdown-menu" style="width: 92.3375px;">\n' +
                                ' <a class="dropdown-item" href="' + " " + data + '"><i class="  "></i> Edit</a>\n' +
                                ' <a class="dropdown-item" href="' + " " + data + '"><i class=" "></i> Delete</a>\n' +
                                ' </div>\n' +
                                ' </div>';
                        }
                    }
                ]

            };

            table.dataTable(settings);

            $('#search-table').keyup(function() {
                table.fnFilter($(this).val());
            });
        };




        bars();



    } );
</script>
