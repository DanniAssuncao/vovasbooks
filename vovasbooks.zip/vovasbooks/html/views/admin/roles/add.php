
<?php include (HTMLPATH . "modAdmin/head.php"); ?>

<?php include (HTMLPATH . "modAdmin/header.php"); ?>


        <!-- Breadcrumb area Start -->
        <div class="breadcrumb-area bg-color ptb--90" data-bg-color="#f6f6f6">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
                            <h1 class="page-title">Add Role</h1>
                            <ul class="breadcrumb">
                                <li><a href="index.html">User</a></li>
                                <li><a href="index.html">Role</a></li>
                                <li class="current"><span>Add Role</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Breadcrumb area End -->

        <!-- Main Content Wrapper Start -->
        <div class="main-content-wrapper">
            <div class="page-content-inner">
                <div class="container">
                    <div class="row pt--50 pt-md--40 pt-sm--20">
                        <div class="col-12">
                            <!-- User Action Start -->
                            <div class="user-actions user-actions__coupon">
                                <div class="message-box mb--30">
                                    <p><i class="fa fa-exclamation-circle"></i> Fill in the fields with the details of the book</p>
                                </div>

                            </div>
                            <!-- User Action End -->
                        </div>
                    </div> 
                    <div class="row pb--80 pb-md--60 pb-sm--40">
                        <!-- Checkout Area Start -->  
                        <div class="col-lg-6">
                            <div class="checkout-title mt--10">
                                <h2>Role Details</h2>
                            </div>
                            <div class="checkout-form">
                                <form  class="form form--checkout" action="<?=PATH?>admin/user/role/insert" method="post" >
                                    <div class="form-row mb--20">
                                        <div class="form__group col-md-12 mb-sm--30">
                                            <label for="billing_fname" class="form__label form__label--2"> Name  <span class="required">*</span></label>
                                            <input type="text" name="name_role"  class="form__input form__input--2">
                                        </div>
                                        <div class="form__group col-md-12">
                                            <label for="billing_lname" class="form__label form__label--2"> Description  <span class="required">*</span></label>
                                            <input type="text" name="description_role"  class="form__input form__input--2">
                                        </div>
                                    </div>


                                    <div class="form__group mr--30">
                                        <input type="submit" value="Submit" class="btn-submit">
                                    </div>

                                </form>
                            </div>
                        </div>

                        <!-- Checkout Area End -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Content Wrapper Start -->

<?php include (HTMLPATH . "modAdmin/footer.php"); ?>


<?php include (HTMLPATH . "modAdmin/loader.php"); ?>


<?php include (HTMLPATH . "modAdmin/scripts.php"); ?>