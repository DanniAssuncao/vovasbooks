<?php include (HTMLPATH . "mod/head.php"); ?>

<?php include (HTMLPATH . "mod/header.php"); ?>

        <!-- Main Content Wrapper Start -->
        <div class="main-content-wrapper">
            <div class="page-content-inner ptb--80">
                <div class="container">
                    <div class="row no-gutters mb--80">
                        <div class="col-lg-7 product-main-image">
                            <div class="product-image">
                                <div class="product-gallery vertical-slide-nav">
                                    <div class="product-gallery__large-image mb-md--30">
                                        <div class="product-gallery__wrapper">
                                            <div class="zakas-element-carousel main-slider image-popup"
                                            data-slick-options='{
                                                "slidesToShow": 1,
                                                "slidesToScroll": 1,
                                                "infinite": true,
                                                "arrows": false, 
                                                "asNavFor": ".nav-slider"
                                            }'>
                                                <figure class="product-gallery__image zoom">
                                                    <img src="<?=$book['cover']?>" alt="Product">
                                                    <div class="product-gallery__actions">
                                                        <button class="action-btn btn-zoom-popup"><i class="fa fa-eye"></i></button>
                                                        <a href="https://www.youtube.com/watch?v=Rp19QD2XIGM" class="action-btn video-popup"><i class="fa fa-play"></i></a>
                                                    </div>
                                                </figure>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-gallery__nav-image">
                                        <div class="zakas-element-carousel nav-slider slick-vertical product-slide-nav" 
                                        data-slick-options='{
                                            "spaceBetween": "30px",
                                            "slidesToShow": 3,
                                            "slidesToScroll": 1,
                                            "vertical": true,
                                            "swipe": true,
                                            "verticalSwiping": true,
                                            "infinite": true,
                                            "focusOnSelect": true,
                                            "asNavFor": ".main-slider",
                                            "arrows": true, 
                                            "prevArrow": {"buttonClass": "slick-btn slick-prev", "iconClass": "fa fa-angle-up" },
                                            "nextArrow": {"buttonClass": "slick-btn slick-next", "iconClass": "fa fa-angle-down" }
                                        }'
                                        data-slick-responsive='[
                                            {
                                                "breakpoint":767, 
                                                "settings": {
                                                    "slidesToShow": 4,
                                                    "vertical": false
                                                } 
                                            },
                                            {
                                                "breakpoint":575, 
                                                "settings": {
                                                    "slidesToShow": 3,
                                                    "vertical": false
                                                } 
                                            },
                                            {
                                                "breakpoint":480, 
                                                "settings": {
                                                    "slidesToShow": 2,
                                                    "vertical": false
                                                } 
                                            }
                                        ]'>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="col-xl-4 offset-xl-1 col-lg-5 product-main-details mt-md--50">
                            <div class="product-summary pl-lg--30 pl-md--0">
                                <div class="product-navigation text-right mb--20">
                                    <a href="#" class="prev"><i class="fa fa-angle-double-left"></i></a>
                                    <a href="#" class="next"><i class="fa fa-angle-double-right"></i></a>
                                </div>
                                <div class="product-rating d-flex mb--20">
                                    <div class="star-rating star-four">
                                        <span>Rated <strong class="rating">5.00</strong> out of 5</span>
                                    </div>
                                </div>
                                <h3 class="product-title mb--20"><?=$book['name']?></h3>
                                <p class="product-short-description mb--20"> <?=$book['description']?> </p>
                                <div class="product-price-wrapper mb--25">
                                    <span class="money">Available Quantity </span>
                                    <span class="price-separator">-</span>
                                    <span class="money"><?=$book['qtd']?></span>
                                </div>

                                <div class="product-action d-flex flex-sm-row align-items-sm-center flex-column align-items-start mb--30">

                                    <button type="button" class="btn btn-small btn-bg-red btn-color-white btn-hover-2" onclick="window.location.href='cart.html'">
                                        Request
                                    </button>
                                </div>  

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- Main Content Wrapper End -->



<?php include (HTMLPATH . "mod/footer.php"); ?>


<?php include (HTMLPATH . "mod/cart.php"); ?>

<?php include (HTMLPATH . "mod/loader.php"); ?>

<?php include (HTMLPATH . "mod/scripts.php"); ?>