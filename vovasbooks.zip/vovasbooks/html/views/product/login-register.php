
<?php include (HTMLPATH . "mod/head.php"); ?>

<?php include (HTMLPATH . "mod/header.php"); ?>

        <!-- Main Content Wrapper Start -->
        <div class="main-content-wrapper">
            <div class="page-content-inner pt--75 pb--80">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 mb-sm--50">
                            <div class="login-box">
                                <h3 class="heading__tertiary mb--30">Login</h3>
                                <form class="form form--login" method="post" action="<?=PATH?>checkout/login">
                                    <div class="form__group mb--20">
                                        <label class="form__label form__label--2" for="username_email">Username  <span class="required">*</span></label>
                                        <input type="text" class="form__input form__input--2" id="username" name="username">
                                    </div>
                                    <div class="form__group mb--20">
                                       <label class="form__label form__label--2" for="login_password">Password <span class="required">*</span></label>
                                        <input type="password" class="form__input form__input--2" id="login_password" name="password">
                                    </div>
                                    <div class="d-flex align-items-center mb--20">
                                        <div class="form__group mr--30">
                                            <input type="submit" value="Log in" class="btn-submit">
                                        </div>
                                        <div class="form__group">
                                            <label class="form__label checkbox-label" for="store_session">
                                                <input type="checkbox" name="store_session" id="store_session">
                                                <span>Remember me</span>
                                            </label>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="col-md-12">

                                <div class="checkout-form">
                                    <form  class="form form--checkout" action="<?=PATH?>admin/student/insert" method="post" >
                                        <div class="col-md-12">
                                            <div class="checkout-title mt--10">
                                                <h2>Profile Details</h2>
                                            </div>
                                            <div class="form-row mb--20">

                                                <div class="form__group col-md-12 mb-sm--30">
                                                    <label for="billing_fname" class="form__label form__label--2"> First Name  <span class="required">*</span></label>
                                                    <input type="text" name="first_name"  class="form__input form__input--2">
                                                </div>
                                                <div class="form__group col-md-12">
                                                    <label for="billing_lname" class="form__label form__label--2"> Last Name  <span class="required">*</span></label>
                                                    <input type="text" name="last_name"  class="form__input form__input--2">
                                                </div>

                                                <div class="form__group col-md-12">
                                                    <label for="billing_lname" class="form__label form__label--2"> Address  <span class="required">*</span></label>
                                                    <input type="text" name="address"  class="form__input form__input--2">
                                                </div>

                                                <div class="form__group col-md-12">
                                                    <label for="billing_lname" class="form__label form__label--2"> Id Number  <span class="required">*</span></label>
                                                    <input type="text" name="id_number"  class="form__input form__input--2">
                                                </div>

                                                <div class="form__group col-md-12">
                                                    <label for="billing_lname" class="form__label form__label--2"> Phone  Number  <span class="required">*</span></label>
                                                    <input type="number" name="phone_number"  class="form__input form__input--2">
                                                </div>

                                                <div class="form-row mb--20">
                                                    <div class="form__group col-12">
                                                        <label  class="form__label form__label--2">School <span class="required">*</span></label>
                                                        <select  name="school" class="form__input form__input--2 nice-select">
                                                            <option value="">Select a school…</option>

                                                            <?php if(!empty($schools)){

                                                                foreach ($schools as $school){?>
                                                                    <option value="<?=$school['school_id']?>"><?=$school['name']?></option>
                                                                <?php   }
                                                            }?>


                                                        </select>
                                                    </div>
                                                </div>


                                            </div>
                                        </div>

                                        <div class="col-md-12">

                                            <div class="checkout-title mt--10">
                                                <h2>Account Details</h2>
                                            </div>
                                            <div class="form-row mb--20">
                                                <div class="form__group col-md-12 mb-sm--30">
                                                    <label for="billing_fname" class="form__label form__label--2"> Username  <span class="required">*</span></label>
                                                    <input type="text" name="username"  class="form__input form__input--2">
                                                </div>
                                                <div class="form__group col-md-12">
                                                    <label for="billing_lname" class="form__label form__label--2"> Email  <span class="required">*</span></label>
                                                    <input type="email" name="email"  class="form__input form__input--2">
                                                </div>

                                                <div class="form__group col-md-12">
                                                    <label for="billing_lname" class="form__label form__label--2"> Password  <span class="required">*</span></label>
                                                    <input type="text" name="password"  class="form__input form__input--2">
                                                </div>





                                            </div>
                                        </div>



                                        <div class="form__group mr--30">
                                            <input type="submit" value="Submit" class="btn-submit">
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Content Wrapper Start -->


<?php include (HTMLPATH . "mod/footer.php"); ?>


<?php include (HTMLPATH . "mod/cart.php"); ?>

<?php include (HTMLPATH . "mod/loader.php"); ?>

<?php include (HTMLPATH . "mod/scripts.php"); ?>