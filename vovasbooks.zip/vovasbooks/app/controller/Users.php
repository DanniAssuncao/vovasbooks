<?php


namespace App\controller;


use App\dao\AbstractDao;
use App\model\User;
use const Sodium\CRYPTO_GENERICHASH_BYTES;

class Users
{

    private $container;


    /**
     * Dashboard constructor.
     * @param $container
     */
    public function __construct($container)
    {
        $this->container = $container;
    }

    public function index($request, $response)
    {
        $vars = array();

        $userObjs = array();

        $users  = (new AbstractDao("bk_user"))->select();



        foreach ($users as $user){

            array_push($userObjs, User::construct($user));
        }




        $vars['listOfUsers'] = json_encode($userObjs);

        return $this->container->view->render($response, 'admin/user/list.php', $vars);

    }




    public function add($request, $response)
    {

        $vars = array();

        $roles =  (new AbstractDao("bk_user_role"))->select();

        $vars['roles'] = $roles;

        return $this->container->view->render($response, 'admin/user/add.php', $vars);

    }


    public function insert($request, $response)
    {


        $post = $request->getParsedBody();



        $username = filter_var($post['user_name'], FILTER_SANITIZE_STRING);
        $useremail = filter_var($post['user_email'], FILTER_SANITIZE_STRING);
        $userpassword = filter_var($post['user_password'], FILTER_SANITIZE_STRING);
        $userrole = filter_var($post['user_role'], FILTER_SANITIZE_STRING);
        $userstatus = filter_var($post['user_status'], FILTER_SANITIZE_STRING);




        if( !empty($username) && !empty($useremail) &&  !empty($userpassword) && !empty($userrole) &&  !empty($userstatus)){

            $date = date("Y-m-d H:s:i");
            $hashPassword = password_hash($userpassword, PASSWORD_DEFAULT);


            $userObj = new User("", $username, $useremail, $hashPassword, $userrole, $date, $userstatus);


            (new AbstractDao("bk_user"))->insert($userObj->columns(), $userObj->value());

            return $response->withStatus(302)->withHeader('Location', PATH . "admin/user/" );




        }else {

            return $response
                ->withStatus(302)
                ->withHeader('Content-Type', 'text/html')->write('<script>history.back()</script>');

        }



    }

}