<?php


namespace App\controller;


class Checkout
{

    private $container;


    /**
     * Dashboard constructor.
     * @param $container
     */
    public function __construct($container)
    {
        $this->container = $container;
    }


    public function page($request, $response)
    {

        return $this->container->view->render($response, 'product/login-register.php');

    }

}