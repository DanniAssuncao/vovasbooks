<?php


namespace App\controller;


use App\dao\AbstractDao;

class Library
{
    private $container;

    /**
     * Dashboard constructor.
     * @param $container
     */
    public function __construct($container)
    {
        $this->container = $container;
    }

    public function index($request, $response)
    {

        $vars = array();
        $books = new AbstractDao("bk_book");
        $categories = new AbstractDao("bk_category");

        $getBooks = $books->select("*");
        $getCategories = $categories->select();



        if(!empty($getCategories)){

            $vars['categories'] = $getCategories ;
        }

        if(!empty($getBooks)){

            $vars['books'] = $getBooks ;
        }


        return $this->container->view->render($response, 'library/library.php', $vars);

    }


    public function product($request, $response, $args)
    {

        $vars = array();
        $books = new AbstractDao("bk_book");

        $getBooks = $books->select("*", "where book_id = " .$args['id']);



        if(!empty($getBooks)){

            $vars['book'] = $getBooks[0] ;
        }


        return $this->container->view->render($response, 'product/product-details.php', $vars);

    }

}