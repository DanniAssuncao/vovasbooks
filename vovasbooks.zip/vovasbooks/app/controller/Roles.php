<?php


namespace App\controller;


use App\dao\AbstractDao;
use App\model\UserRole;

class Roles
{
    private $container;


    /**
     * Dashboard constructor.
     * @param $container
     */
    public function __construct($container)
    {
        $this->container = $container;
    }

    public function index($request, $response)
    {
        $vars = array();


        $rolesList  = (new AbstractDao("bk_user_role"))->select();


        $vars['listOfRoles'] = json_encode($rolesList);

        return $this->container->view->render($response, 'admin/roles/list.php', $vars);

    }


    public function add($request, $response)
    {


        return $this->container->view->render($response, 'admin/roles/add.php');

    }


    public function insert($request, $response)
    {


        $post = $request->getParsedBody();



        $name = filter_var($post['name_role'], FILTER_SANITIZE_STRING);
        $description = filter_var($post['description_role'], FILTER_SANITIZE_STRING);




        if( !empty($name) && !empty($description)){



            $roleObj = new UserRole("", $name, $description);

            (new AbstractDao("bk_user_role"))->insert($roleObj->columns(), $roleObj->value());

            return $response->withStatus(302)->withHeader('Location', PATH . "admin/user/role" );




        }else {

            return $response
                ->withStatus(302)
                ->withHeader('Content-Type', 'text/html')->write('<script>history.back()</script>');

        }



    }
}