<?php


namespace App\controller;


use App\dao\AbstractDao;
use App\model\Book;
use Slim\Http\UploadedFile;

class Books
{

    private $container;


    /**
     * Dashboard constructor.
     * @param $container
     */
    public function __construct($container)
    {
        $this->container = $container;
    }

    public function index($request, $response)
    {
        $vars = array();
        $booksObjs = array();

        $books  = (new AbstractDao("bk_book"))->select();



        foreach ($books as $book){

            array_push($booksObjs, Book::construct($book));
        }



        $vars['listOfBooks'] = json_encode($booksObjs);

        return $this->container->view->render($response, 'admin/book/list.php', $vars);

    }

    public function add($request, $response)
    {

        $vars = array();

        $categoryDao = (new AbstractDao("bk_category"))->select();

        if(!empty($categoryDao)){

            $vars['categories'] = $categoryDao;
        }




        return $this->container->view->render($response, 'admin/book/add.php', $vars);

    }


    public function insert($request, $response)
    {


        $post = $request->getParsedBody();



        $name = filter_var($post['name_book'], FILTER_SANITIZE_STRING);
        $author = filter_var($post['author_book'], FILTER_SANITIZE_STRING);
        $publisher = filter_var($post['pulisher_book'], FILTER_SANITIZE_STRING);
        $editor = filter_var($post['editor_book'], FILTER_SANITIZE_STRING);
        $category = filter_var($post['category_book'], FILTER_SANITIZE_STRING);
        $units = filter_var($post['quatity_book'], FILTER_SANITIZE_STRING);
        $isFeatured = filter_var($post['isFeatured_book'], FILTER_SANITIZE_STRING);
        $uploadedFiles = $request->getUploadedFiles();
        $cover = $uploadedFiles['cover_book'];
        $description = filter_var($post['description_book'], FILTER_SANITIZE_STRING);



        if(!empty($name) && !empty($author) && !empty($publisher) && !empty($editor) && !empty($category) && !empty($units) && !empty($isFeatured) && !empty($cover) && !empty($description)){


            $date = date("Y-m-d H:i:s");
            $status = "Active";



            $bookObj = new Book("", $name,$author, $publisher, $editor, $category, $units, $date, $status, 0, $isFeatured, $this->uploadImage($cover), $description);

            (new AbstractDao("bk_book"))->insert($bookObj->columns(), $bookObj->value());

            return $response->withStatus(302)->withHeader('Location', '../book/add' );




        }else {

            return $response
                ->withStatus(302)
                ->withHeader('Content-Type', 'text/html')->write('<script>history.back()</script>');

        }



    }


    public function edit($request, $response)
    {

    }

    public function update($request, $response)
    {

    }

    public function view($request, $response)
    {

    }



    function moveUploadedFile($directory, UploadedFile $uploadedFile)
    {
        $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
        $basename = bin2hex(random_bytes(8)); // see http://php.net/manual/en/function.random-bytes.php
        $filename = sprintf('%s.%0.8s', $basename, $extension);

        $uploadedFile->moveTo($directory . DIRECTORY_SEPARATOR . $filename);

        return $filename;


    }


    function removeImage($imageBaseName){
        $directory = PATH. 'assets' . DIRECTORY_SEPARATOR . 'img' . DIRECTORY_SEPARATOR . 'products' . DIRECTORY_SEPARATOR;

        $basename = basename($imageBaseName);

        $imageToRemove = $directory.$basename;

        @unlink( $imageToRemove );

    }

    private function uploadImage($image){



        $allow = array("jpg", "jpeg", "gif", "png");

        $directory = PATH . 'assets' . DIRECTORY_SEPARATOR . 'img' . DIRECTORY_SEPARATOR . 'products';

        if ($image->getError() === UPLOAD_ERR_OK) {

            if (in_array(pathinfo($image->getClientFileName(), PATHINFO_EXTENSION), $allow)) {

                $filename = $this->moveUploadedFile($directory, $image);

                $link = $directory = PATH. 'assets' . "/" . 'img' . "/" . 'products/';

                return $link . $filename;
            }

            return null;

        }
    }



    }