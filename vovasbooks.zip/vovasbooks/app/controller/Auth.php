<?php


namespace App\controller;


use App\dao\AbstractDao;

class Auth
{
    private $container;

    /**
     * Dashboard constructor.
     * @param $container
     */
    public function __construct($container)
    {
        $this->container = $container;
    }

    public function index($request, $response)
    {



        return $this->container->view->render($response, 'admin/auth/login.php');

    }


    public function login($request, $response)
    {

        $post = $request->getParsedBody();



        $username = filter_var($post['username'], FILTER_SANITIZE_STRING);
        $password = filter_var($post['password'], FILTER_SANITIZE_STRING);





        if(!empty($username) && !empty($password)){



            $user = (new AbstractDao("bk_user"))->select( "*", "where username = " .$username );



            if(!empty($user)){

                if ( password_verify($password,  $user[0])){

                    session_start();
                    $_SESSION['user'] = $user[0]['id_user'];

                    return $response->withStatus(302)->withHeader('Location', PATH . 'library' );

                }



            }else {

                return $response
                    ->withStatus(302)
                    ->withHeader('Content-Type', 'text/html')->write('<script>history.back()</script>');
            }


        }else {

            return $response
                ->withStatus(302)
                ->withHeader('Content-Type', 'text/html')->write('<script>history.back()</script>');

        }

    }

}