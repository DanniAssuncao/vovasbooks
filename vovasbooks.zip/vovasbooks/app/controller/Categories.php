<?php


namespace App\controller;


use App\dao\AbstractDao;
use App\model\Category;

class Categories
{

    private $container;


    /**
     * Dashboard constructor.
     * @param $container
     */
    public function __construct($container)
    {
        $this->container = $container;
    }

    public function index($request, $response)
    {
        $vars = array();


        $categories  = (new AbstractDao("bk_category"))->select();


        $vars['listOfCategories'] = json_encode($categories);

        return $this->container->view->render($response, 'admin/category/list.php', $vars);

    }


    public function add($request, $response)
    {


        return $this->container->view->render($response, 'admin/category/add.php');

    }


    public function insert($request, $response)
    {


        $post = $request->getParsedBody();



        $name = filter_var($post['name_category'], FILTER_SANITIZE_STRING);
        $description = filter_var($post['description_category'], FILTER_SANITIZE_STRING);




        if( !empty($name) && !empty($description)){



            $categoryObj = new Category("", $name, $description);

            (new AbstractDao("bk_category"))->insert($categoryObj->columns(), $categoryObj->value());

            return $response->withStatus(302)->withHeader('Location', PATH . "admin/category" );




        }else {

            return $response
                ->withStatus(302)
                ->withHeader('Content-Type', 'text/html')->write('<script>history.back()</script>');

        }



    }



}