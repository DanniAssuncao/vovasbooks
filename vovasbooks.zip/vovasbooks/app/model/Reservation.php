<?php


namespace App\model;


class Reservation
{
    private $res_id;
    private $date_issued;
    private $date_returned;
    private $address_delivery;
    private $status;

    /**
     * Reservation constructor.
     * @param $res_id
     * @param $date_issued
     * @param $date_returned
     * @param $address_delivery
     * @param $status
     */
    public function __construct($res_id, $date_issued, $date_returned, $address_delivery, $status)
    {
        $this->res_id = $res_id;
        $this->date_issued = $date_issued;
        $this->date_returned = $date_returned;
        $this->address_delivery = $address_delivery;
        $this->status = $status;
    }


    /**
     * @return mixed
     */
    public function getResId()
    {
        return $this->res_id;
    }

    /**
     * @param mixed $res_id
     */
    public function setResId($res_id)
    {
        $this->res_id = $res_id;
    }

    /**
     * @return mixed
     */
    public function getDateIssued()
    {
        return $this->date_issued;
    }

    /**
     * @param mixed $date_issued
     */
    public function setDateIssued($date_issued)
    {
        $this->date_issued = $date_issued;
    }

    /**
     * @return mixed
     */
    public function getDateReturned()
    {
        return $this->date_returned;
    }

    /**
     * @param mixed $date_returned
     */
    public function setDateReturned($date_returned)
    {
        $this->date_returned = $date_returned;
    }

    /**
     * @return mixed
     */
    public function getAddressDelivery()
    {
        return $this->address_delivery;
    }

    /**
     * @param mixed $address_delivery
     */
    public function setAddressDelivery($address_delivery)
    {
        $this->address_delivery = $address_delivery;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }



    public function toArray(){
        return array(
            "res_id" => $this->res_id,
            "date_issued" => $this->date_issued,
            "date_returned" => $this->date_returned,
            "address_delivery" => $this->address_delivery,
            "status" => $this->status
        );
    }


}