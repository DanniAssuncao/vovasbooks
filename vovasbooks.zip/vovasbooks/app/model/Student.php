<?php


namespace App\model;


use App\dao\AbstractDao;

class Student
{

    public $stu_id;
    public $school_id;
    public $ps_id;

    /**
     * Student constructor.
     * @param $stu_id
     * @param $school_id
     * @param $ps_id
     */
    public function __construct($stu_id ="", $school_id ="", $ps_id ="")
    {
        $this->stu_id = $stu_id;
        $this->school_id = $school_id;
        $this->ps_id = $ps_id;
    }



    public static function construct($array)
    {
        $obj = new Student();
        $obj->setPsId($array['ps_id']);
        $obj->setSchoolId($array['school_id']);
        $obj->setStuId($array['stu_id']);





        return $obj;

    }





    /**
     * @return mixed
     */
    public function getStuId()
    {
        return $this->stu_id;
    }

    /**
     * @param mixed $stu_id
     */
    public function setStuId($stu_id)
    {
        $this->stu_id = $stu_id;
    }

    /**
     * @return mixed
     */
    public function getSchoolId()
    {
        return $this->school_id;
    }

    /**
     * @param mixed $school_id
     */
    public function setSchoolId($school_id)
    {

       $school =  ( new AbstractDao("bk_school"))->select("*", "where school_id = ". $school_id);
        $this->school_id = $school[0];
    }

    /**
     * @return mixed
     */
    public function getPsId()
    {
        return $this->ps_id;
    }

    /**
     * @param mixed $ps_id
     */
    public function setPsId($ps_id)
    {
        $person =  ( new AbstractDao("bk_person"))->select("*", "where ps_id  = ". $ps_id);
        $this->ps_id = $person[0];
    }


    public function columns(){
        return array(
            "stu_id",
            "school_id",
            "ps_id"


        );
    }

    public function values(){
        return array(
            $this->stu_id,
            $this->school_id,
            $this->ps_id


        );
    }

    public function toArray(){
        return array(
            "stu_id" => $this->stu_id,
            "school_id" => $this->school_id,
            "ps_id" => $this->ps_id
        );
    }


}