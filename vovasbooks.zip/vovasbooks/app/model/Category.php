<?php


namespace App\model;


class Category
{

    private $categ_id;
    private $name;
    private $description;

    /**
     * Category constructor.
     * @param $categ_id
     * @param $name
     * @param $description
     */
    public function __construct($categ_id, $name, $description)
    {
        $this->categ_id = $categ_id;
        $this->name = $name;
        $this->description = $description;
    }

    /**
     * @return mixed
     */
    public function getCategId()
    {
        return $this->categ_id;
    }

    /**
     * @param mixed $categ_id
     */
    public function setCategId($categ_id)
    {
        $this->categ_id = $categ_id;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param mixed $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    public function columns(){
        return array(
            "categ_id",
            "name",
            "description"

        );
    }


    public function value(){
        return array(
            $this->categ_id,
            $this->name,
            $this->description

        );
    }

    public function toArray(){
        return array(
            "categ_id" => $this->categ_id,
            "name" => $this->name,
            "description" => $this->description
        );
    }

}