<?php


namespace App\model;


class Cart
{

    public $cart_id;
    public $book_id;
    public $reservationId;
    public $user_id;

    /**
     * Cart constructor.
     * @param $cart_id
     * @param $book_id
     * @param $reservationId
     * @param $user_id
     */
    public function __construct($cart_id, $book_id, $reservationId, $user_id)
    {
        $this->cart_id = $cart_id;
        $this->book_id = $book_id;
        $this->reservationId = $reservationId;
        $this->user_id = $user_id;
    }

    /**
     * @return mixed
     */
    public function getCartId()
    {
        return $this->cart_id;
    }

    /**
     * @param mixed $cart_id
     */
    public function setCartId($cart_id)
    {
        $this->cart_id = $cart_id;
    }

    /**
     * @return mixed
     */
    public function getBookId()
    {
        return $this->book_id;
    }

    /**
     * @param mixed $book_id
     */
    public function setBookId($book_id)
    {
        $this->book_id = $book_id;
    }

    /**
     * @return mixed
     */
    public function getReservationId()
    {
        return $this->reservationId;
    }

    /**
     * @param mixed $reservationId
     */
    public function setReservationId($reservationId)
    {
        $this->reservationId = $reservationId;
    }

    /**
     * @return mixed
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * @param mixed $user_id
     */
    public function setUserId($user_id)
    {
        $this->user_id = $user_id;
    }


    public function toArray(){
        return array(
            "cart_id" => $this->cart_id,
            "book_id" => $this->book_id,
            "reservation_id" => $this->reservationId,
            "user_id" => $this->user_id
        );
    }


}