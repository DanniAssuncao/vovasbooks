<?php


namespace App\model;


use App\dao\AbstractDao;

class User
{

    public $id_user;
    public $username;
    public $email;
    public $password;
    public $user_role_id;
    public $date_created;
    public $lastLogin;
    public $status;

    /**
     * User constructor.
     * @param $id_user
     * @param $username
     * @param $email
     * @param $password
     * @param $user_role_id
     * @param $date_created
     * @param $lastLogin
     */
    public function __construct($id_user = "", $username = "", $email = "", $password = "", $user_role_id = "", $date_created = "", $lastLogin = "", $status = "")
    {
        $this->id_user = $id_user;
        $this->username = $username;
        $this->email = $email;
        $this->password = $password;
        $this->user_role_id = $user_role_id;
        $this->date_created = $date_created;
        $this->lastLogin = $lastLogin;
        $this->status = $status;
    }


    public static function construct($array)
    {
        $obj = new User();
        $obj->setIdUser($array['id_user']);
        $obj->setUsername($array['username']);
        $obj->setEmail($array['email']);
        $obj->setPassword($array['password']);
        $obj->setDateCreated($array['date_created']);
        $obj->setLastLogin($array['last_login']);
        $obj->setUserRoleId($array['user_role_id']);
        $obj->setStatus($array['status']);




        return $obj;

    }


    /**
     * @return mixed
     */
    public function getIdUser()
    {
        return $this->id_user;
    }

    /**
     * @param mixed $id_user
     */
    public function setIdUser($id_user)
    {
        $this->id_user = $id_user;
    }

    /**
     * @return mixed
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @param mixed $username
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     * @return mixed
     */
    public function getUserRoleId()
    {
        return $this->user_role_id;
    }

    /**
     * @param mixed $user_role_id
     */
    public function setUserRoleId($user_role_id)

    {

        $role = (new AbstractDao("bk_user_role"))->select("*", "where id_role = " . $user_role_id);

        $this->user_role_id = $role[0];
    }

    /**
     * @return mixed
     */
    public function getDateCreated()
    {
        return $this->date_created;
    }

    /**
     * @param mixed $date_created
     */
    public function setDateCreated($date_created)
    {
        $this->date_created = $date_created;
    }

    /**
     * @return mixed
     */
    public function getLastLogin()
    {
        return $this->lastLogin;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }



    /**
     * @param mixed $lastLogin
     */
    public function setLastLogin($lastLogin)
    {
        $this->lastLogin = $lastLogin;
    }


    public function columns(){
        return array(
            "id_user",
            "username",
            "email",
            "password",
            "user_role_id",
            "date_created",
            "last_login",
            "status"




        );
    }


    public function value(){
        return array(
            $this->id_user,
            $this->username,
            $this->email,
            $this->password,
            $this->user_role_id,
            $this->date_created,
            $this->lastLogin,
            $this->status


        );
    }




    public function toArray(){
        return array(
            "id_user" => $this->id_user,
            "username" => $this->username,
            "email" => $this->email,
            "password" => $this->password,
            "user_role_id" => $this->user_role_id,
            "date_created" => $this->date_created,
            "last_login" => $this->lastLogin,
            "status" => $this->status
        );
    }


}