<?php


namespace App\model;


class UserRole
{

    private $id_role;
    private $name;
    private $description;

    /**
     * UserRole constructor.
     * @param $id_role
     * @param $name
     * @param $description
     */
    public function __construct($id_role, $name, $description)
    {
        $this->id_role = $id_role;
        $this->name = $name;
        $this->description = $description;
    }

    /**
     * @return mixed
     */
    public function getIdRole()
    {
        return $this->id_role;
    }

    /**
     * @param mixed $id_role
     */
    public function setIdRole($id_role)
    {
        $this->id_role = $id_role;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param mixed $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    public function columns(){
        return array(
            "id_role",
            "name",
            "description"

        );
    }


    public function value(){
        return array(
            $this->id_role,
            $this->name,
            $this->description

        );
    }


    public function toArray(){
        return array(
            "id_role" => $this->id_role,
            "name" => $this->name,
            "description" => $this->description
        );
    }


}