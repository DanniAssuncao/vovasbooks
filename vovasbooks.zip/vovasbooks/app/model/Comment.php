<?php


namespace App\model;


class Comment
{

    public $comm_id;
    public $book_id;
    public $user_id;
    public $comment;
    public $date_commented;

    /**
     * Comment constructor.
     * @param $comm_id
     * @param $book_id
     * @param $user_id
     * @param $comment
     * @param $date_commented
     */
    public function __construct($comm_id, $book_id, $user_id, $comment, $date_commented)
    {
        $this->comm_id = $comm_id;
        $this->book_id = $book_id;
        $this->user_id = $user_id;
        $this->comment = $comment;
        $this->date_commented = $date_commented;
    }

    /**
     * @return mixed
     */
    public function getCommId()
    {
        return $this->comm_id;
    }

    /**
     * @param mixed $comm_id
     */
    public function setCommId($comm_id)
    {
        $this->comm_id = $comm_id;
    }

    /**
     * @return mixed
     */
    public function getBookId()
    {
        return $this->book_id;
    }

    /**
     * @param mixed $book_id
     */
    public function setBookId($book_id)
    {
        $this->book_id = $book_id;
    }

    /**
     * @return mixed
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * @param mixed $user_id
     */
    public function setUserId($user_id)
    {
        $this->user_id = $user_id;
    }

    /**
     * @return mixed
     */
    public function getComment()
    {
        return $this->comment;
    }

    /**
     * @param mixed $comment
     */
    public function setComment($comment)
    {
        $this->comment = $comment;
    }

    /**
     * @return mixed
     */
    public function getDateCommented()
    {
        return $this->date_commented;
    }

    /**
     * @param mixed $date_commented
     */
    public function setDateCommented($date_commented)
    {
        $this->date_commented = $date_commented;
    }




    public function toArray(){
        return array(
            "comm_id" => $this->comm_id,
            "book_id" => $this->book_id,
            "user_id" => $this->user_id,
            "comment" => $this->comment,
            "date_commented" => $this->date_commented
        );
    }


}