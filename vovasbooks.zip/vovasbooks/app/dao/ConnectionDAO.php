<?php
namespace App\dao;

class ConnectionDAO{


    public static function databaseConnection(){

         $hostname = "localhost";
         $user = "root";
         $pass = "";
         $database = "books_rent";

        $connection = mysqli_connect($hostname, $user, $pass, $database);

        if (!$connection) {

            die(trigger_error("Unable to connect with database"));
            return false;

        } else {

            $db = mysqli_select_db($connection, $database);

            if (!$db) {

                die(trigger_error("Unable to connect with database"));

                return false;

            } else {

                return $connection;

            }

        }


    }
}