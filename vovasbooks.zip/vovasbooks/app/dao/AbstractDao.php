<?php


namespace App\dao;




class AbstractDao
{


    private $connection;
    private $tableInstance;


    /**
     * AbstractDao constructor.
     * @param $tableInstance
     */
    public function __construct($tableInstance)
    {
        $this->connection = ConnectionDAO::databaseConnection();
        $this->tableInstance = $tableInstance;

    }


    public function insert($column, $value){


        if ((is_array($column)) and (is_array($value))) {

            if (count($column) == count($value)) {

                $insertSql = "INSERT INTO {$this->tableInstance}(" . implode(', ', $column) . ")
                            VALUES ('" . implode('\',\'', $value) . "')";


            } else {

                return false;

            }

        } else {

            $mysqli = $this->connection;


            $value = $mysqli->real_escape_string($value);

            $insertSql = "INSERT INTO {$this->tableInstance} ({$column}) VALUES ('{$value}')";

            CloseConnection::closeConection($mysqli);



        }

        if ($conction = $this->connection) {


            if ($conction->query($insertSql)) {

                $id = mysqli_insert_id($conction);

                CloseConnection::closeConection($conction);
                return $id;

            } else {
//            echo("Query invalida");

                trigger_error("Query not valid");
                return false;
            }

        } else {

            header('location:../../error.php');

            return false;

        }

    }

    public function update($column, $value, $where){

        if((is_array($column)) and (is_array($value))){

            if(count($column) == count($value)){

                $value_column = NULL;

                for($i=0;$i<count($column);$i++){

                    $value_column .="{$column[$i]} = '{$value[$i]}',";
                }

                $value_column = substr($value_column,0,-1);

                $update = "UPDATE {$this->tableInstance} SET {$value_column} {$where}";

            }else{

                return false;

            }

        }else{

            $update = "UPDATE {$this->tableInstance} SET {$column} = '{$value}' {$where} ";

        }

        if($connection = $this->connection){

            if(mysqli_query($connection,$update)){

               CloseConnection::closeConection($connection);
                return true;

            }else{

                echo("Query not valid");
                return false;
            }

        }else{

            header('location:../../error.php');

            return false;

        }
    }

    public function select($column = "*",$where = NULL,$order = NULL,$limit = NULL){

        $sql = "SELECT {$column} FROM {$this->tableInstance} {$where} {$order} {$limit}";

        if($connection = $this->connection){

            if($query = mysqli_query($connection,$sql)){

                if(mysqli_num_rows($query)>0){

                    $total_results = array();

                    while($result = mysqli_fetch_assoc($query)){

                        $total_results[] = $result;

                    }

                    CloseConnection::closeConection($connection);

                    return $total_results;
                }else{

                    return false;

                }

            }else{

                return false;

            }

        }else{

            header('location:../../error.php');

            return false;

        }

    }

    public function delete($where){

        $deleteSQL = "DELETE FROM {$this->tableInstance} {$where} ";

        if($connection = connect()){

            if(mysqli_query($connection,$deleteSQL)){

              CloseConnection::closeConection($connection);
                return true;

            }else{

                echo("Query not valid");
                return false;
            }

        }else{
            header('location:../../error.php');

            return false;

        }
    }


}