<?php


namespace App\dao;


class CloseConnection
{

    public static function closeConection($conection){


        $close = mysqli_close($conection);

        if(!$close){

            echo("Unable to close connection");

            return false;
        }else {

            return true;
        }
    }

}