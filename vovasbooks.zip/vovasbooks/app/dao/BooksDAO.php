<?php


namespace App\dao;


class BooksDAO extends AbstractDao
{
    public function __construct($tableInstance = "bk_books")
    {
        parent::__construct($tableInstance);
    }


}