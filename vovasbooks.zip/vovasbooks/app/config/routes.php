<?php

defined('FCPATH') or exit('No direct script access allowed');


$app->get('[/]', 'App\controller\Home:index');
$app->get('/login[/]', 'App\controller\Home:index');
$app->get('/dashboard[/]', 'App\controller\Dashboard:index');


$app->group('/library', function () use ($app) {

    $app->get('/product/{id}[/]', 'App\controller\Library:product');
    $app->get('/add[/]', 'App\controller\Books:add');
    $app->get('[/]', 'App\controller\Library:index');



});


$app->group('/checkout', function () use ($app) {

    $app->get('/signin[/]', 'App\controller\Checkout:page');
    $app->post('/login[/]', 'App\controller\Auth:login');



});







$app->group('/admin', function () use ($app) {

    $app->get('[/]', 'App\controller\Auth:index');


    $app->group('/book', function () use ($app) {

        $app->post('/insert[/]', 'App\controller\Books:insert');
        $app->get('/add[/]', 'App\controller\Books:add');
        $app->get('[/]', 'App\controller\Books:index');



    });


    $app->group('/student', function () use ($app) {

        $app->post('/insert[/]', 'App\controller\Persons:insertStudent');
        $app->get('/add[/]', 'App\controller\Persons:addStudent');
        $app->get('[/]', 'App\controller\Persons:indexStudent');



    });

    $app->group('/category', function () use ($app) {

        $app->post('/insert[/]', 'App\controller\Categories:insert');
        $app->get('/add[/]', 'App\controller\Categories:add');
        $app->get('[/]', 'App\controller\Categories:index');



    });


    $app->group('/user', function () use ($app) {

        $app->post('/insert[/]', 'App\controller\Users:insert');
        $app->get('/add[/]', 'App\controller\Users:add');
        $app->get('[/]', 'App\controller\Users:index');

        $app->group('/role', function () use ($app) {

            $app->post('/insert[/]', 'App\controller\Roles:insert');
            $app->get('/add[/]', 'App\controller\Roles:add');
            $app->get('[/]', 'App\controller\Roles:index');



        });

    });




});








