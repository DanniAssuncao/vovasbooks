<?php

use Dyorg\TokenAuthentication;
use Prezto\IpFilter\IpFilterMiddleware;
use Prezto\IpFilter\Mode;

session_start();

error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);

defined('FCPATH') or exit('No direct script access allowed');

$e404 = false;

$config = ['settings' => [
    'addContentLengthHeader' => true,
    'displayErrorDetails' => true,
    'debug' => true,
    'mode' => 'production',
    'cache.enabled' => true,
    'cookies.encrypt' => true,
    'cookies.expires' => '20 minutes',
    'cookies.secret_key' => 'AWSEDRFTGYHUJIKOL'
]];

$app = new \Slim\App($config);

$app->add(new \Slim\HttpCache\Cache('public', 86400));

$container = $app->getContainer();

$container['view'] = new \Slim\Views\PhpRenderer(VIEWPATH);

/**
 * @param $container
 * @return \Slim\Csrf\Guard
 */
$container['csrf'] = function ($container) {
    $guard = new \Slim\Csrf\Guard();
    $guard->setFailureCallable(function ($request, $response, $next){
        $request = $request->withAttribute("csrf_status", false);
        return $next($request, $response);
    });
    return $guard;
};

/**
 * @param $container
 * @return \Slim\Flash\Messages
 */
$container['flash'] = function ($container) {
    return new \Slim\Flash\Messages();
};

/**
 * @return \Slim\HttpCache\CacheProvider
 */
$container['cache'] = function () {
    return new \Slim\HttpCache\CacheProvider();
};

///**
// * @return \App\auth\Auth
// */
//$container['auth'] = function () {
//    return new \App\auth\Auth();
//};

///**
// * @return \App\auth\Verify
// */
//$container['verify'] = function () {
//    return new \App\auth\Verify();
//};

$container->get('view')->addAttribute('flash', $container->get('flash'));

//$container->get('view')->addAttribute('auth', [
//    'check' => $container->auth->check(),
//    'user' => $container->auth->user()
//
//]);

$app->add(new \App\middleware\CsrfView($container));

$app->add(new \App\middleware\Cache($container));






require_once 'routes.php';

$app->run();
