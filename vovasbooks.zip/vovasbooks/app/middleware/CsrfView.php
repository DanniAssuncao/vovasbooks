<?php
/**
 * Created by PhpStorm.
 * User: Mr. Macatange
 * Date: 17/04/2018
 * Time: 11:25
 */
namespace App\middleware;


/**
 * Class CsrfView
 * @package App\middleware
 */
class CsrfView extends Middleware
{
    /**
     * @param $request
     * @param $response
     * @param $next
     * @return mixed
     */
    public function __invoke($request, $response, $next)
    {
        $this->container->view->addAttribute('csrf', [
            'field' => '
				<input type="hidden" name="' . $this->container->csrf->getTokenNameKey() . '"
				 value="' . $this->container->csrf->getTokenName() . '">
				<input type="hidden" name="' . $this->container->csrf->getTokenValueKey() . '"
				 value="' . $this->container->csrf->getTokenValue() . '">
			',
        ]);
        $response = $next($request, $response);
        return $response;
    }
}
