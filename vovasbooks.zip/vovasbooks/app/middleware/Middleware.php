<?php
/**
 * Created by PhpStorm.
 * User: Mr. Macatange
 * Date: 17/04/2018
 * Time: 11:29
 */

namespace App\middleware;

/**
 * Class Middleware
 * @package App\middleware
 */
class Middleware
{

    /**
     * @var
     */
    protected $container;

    /**
     * Middleware constructor.
     * @param $container
     */
    public function __construct($container)
    {
        $this->container = $container;
    }
}
