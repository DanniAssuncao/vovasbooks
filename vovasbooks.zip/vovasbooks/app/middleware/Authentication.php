<?php
/**
 * Created by PhpStorm.
 * User: Mr. Macatange
 * Date: 04/03/2018
 * Time: 03:28
 */

namespace App\middleware;


use Prezto\IpFilter\IpFilterMiddleware;
use Prezto\IpFilter\Mode;

/**
 * Class Authentication
 * @package App\middleware
 */
class Authentication
{
    public function getUserByToken($token)
    {
        if ($token != 'usertokensecret') {
            /**
             * The throwable class must implement UnauthorizedExceptionInterface
             */
            new \Exception('Invalid Token');
        }
        $user = [
            'name' => 'Dyorg',
            'id' => 1,
            'permisssion' => 'admin'
        ];
        return $user;
    }
}
